package in.book.vnv.activitys;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import in.book.vnv.R;

public class Chapters extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.activity_chapters);
    }
}
