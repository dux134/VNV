package in.book.vnv.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import in.book.vnv.R;
import in.book.vnv.activitys.Chapters;
import in.book.vnv.entity.ChaptersDataModel;

public class ChaptersAdapter extends RecyclerView.Adapter<ChaptersAdapter.ChapterViewHolder> {
    private ArrayList<ChaptersDataModel> list;
    private Context context;
    private ChaptersAdapter.RecyclerItemListener listener;

    @NonNull
    @Override
    public ChapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chapters,parent,false);
        ChaptersAdapter.ChapterViewHolder holder = new ChaptersAdapter.ChapterViewHolder(view,listener);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ChapterViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public interface RecyclerItemListener {
    }

    public class ChapterViewHolder extends RecyclerView.ViewHolder {

        public ChapterViewHolder(View itemView, RecyclerItemListener listener) {
            super(itemView);
        }
    }
}
