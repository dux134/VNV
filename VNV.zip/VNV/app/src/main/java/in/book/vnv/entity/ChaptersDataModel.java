package in.book.vnv.entity;

public class ChaptersDataModel {
    private String title;
}
