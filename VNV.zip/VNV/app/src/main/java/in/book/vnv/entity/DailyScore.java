package in.book.vnv.entity;

public class DailyScore {
    String id;
    String date;
    String score;

    public DailyScore(String id, String score, String date) {
        this.id = id;
        this.date = date;
        this.score = score;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getScore() {
        return score;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setScore(String score) {
        this.score = score;
    }
}
