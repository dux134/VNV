package in.book.vnv.activitys;

import android.content.Intent;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.Adapter;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;

import in.book.vnv.R;
import in.book.vnv.SliderViewPager;
import in.book.vnv.adapters.DailyTestAdapter;
import in.book.vnv.entity.DailyScore;
import me.relex.circleindicator.CircleIndicator;

public class Dashboard extends AppCompatActivity {
    public ViewPager viewpager;
    private ArrayList<String> sliderImagesUrlList;
    private SliderViewPager sliderViewPager;
    private RecyclerView recyclerView1,recyclerView2;
    private RecyclerView.Adapter adapter1,adapter2;
    private static ArrayList<DailyScore> list1 = new ArrayList<>();
    private static ArrayList<DailyScore> list2 = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, null, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        ImageView toolbar_image = findViewById(R.id.toolbar_image);
        toolbar_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                } else {
                    drawer.openDrawer(GravityCompat.START);
                }
            }
        });
        loadImageInSlider();

        recyclerView1 = findViewById(R.id.quicktext_recycler);
        recyclerView1.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        adapter1 = new DailyTestAdapter(list1,Dashboard.this);
        recyclerView1.setAdapter(adapter1);
        recyclerView1.setItemAnimator(new DefaultItemAnimator());

//        recyclerView2 = findViewById(R.id.practice_recycler);
//        recyclerView2.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
//        adapter2 = new DailyTestAdapter(list2,Dashboard.this);
//        recyclerView2.setAdapter(adapter2);
//        recyclerView2.setItemAnimator(new DefaultItemAnimator());

        LinearLayout practiceLayout = findViewById(R.id.practice_layout);
        practiceLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Dashboard.this,Content.class));
            }
        });
    }

    static {
        list1.add(new DailyScore("1","56","20/10/2019"));
        list1.add(new DailyScore("1","56","20/10/2019"));
        list1.add(new DailyScore("1","56","20/10/2019"));
        list1.add(new DailyScore("1","56","20/10/2019"));
        list1.add(new DailyScore("1","56","20/10/2019"));
        list2.add(new DailyScore("1","56","20/10/2019"));
        list2.add(new DailyScore("1","56","20/10/2019"));
        list2.add(new DailyScore("1","56","20/10/2019"));
        list2.add(new DailyScore("1","56","20/10/2019"));
        list2.add(new DailyScore("1","56","20/10/2019"));
        list2.add(new DailyScore("1","56","20/10/2019"));
    }

    private void loadImageInSlider() {
        sliderImagesUrlList = new ArrayList<String>();
        sliderImagesUrlList.add("https://quotes4ever.com/wp-content/uploads/2017/09/luxury-quotes-46.jpg");
        sliderImagesUrlList.add("https://quotes4ever.com/wp-content/uploads/2017/09/luxury-quotes-46.jpg");
        sliderImagesUrlList.add("https://quotes4ever.com/wp-content/uploads/2017/09/luxury-quotes-46.jpg");
        sliderImagesUrlList.add("https://quotes4ever.com/wp-content/uploads/2017/09/luxury-quotes-46.jpg");
        sliderImagesUrlList.add("https://quotes4ever.com/wp-content/uploads/2017/09/luxury-quotes-46.jpg");
        viewpager = (ViewPager) findViewById(R.id.viewpager);
        sliderViewPager = new SliderViewPager(viewpager,Dashboard.this, sliderImagesUrlList);
        viewpager.setAdapter(sliderViewPager);
        CircleIndicator indicator = (CircleIndicator)findViewById(R.id.indicator);
        viewpager.setCurrentItem(2);
        indicator.setViewPager(viewpager);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard, menu);
        return true;
    }
}